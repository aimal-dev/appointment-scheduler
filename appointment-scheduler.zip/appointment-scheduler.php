<?php
/**
 * Plugin Name: Appointment Scheduler
 * Plugin URI: https://example.com/appointment-scheduler
 * Description: A beautiful appointment scheduling system with calendar and time slot selection. Sends email notifications to admin.
 * Version: 1.1.0
 * Author: M.Aimal
 * Author URI: https://example.com
 * License: GPL v2 or later
 * Text Domain: appointment-scheduler
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('APPOINTMENT_SCHEDULER_VERSION', '1.1.0');
define('APPOINTMENT_SCHEDULER_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('APPOINTMENT_SCHEDULER_PLUGIN_URL', plugin_dir_url(__FILE__));

class Appointment_Scheduler {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_submit_appointment', array($this, 'handle_appointment_submission'));
        add_action('wp_ajax_nopriv_submit_appointment', array($this, 'handle_appointment_submission'));
        add_action('wp_ajax_get_time_slots', array($this, 'get_time_slots'));
        add_action('wp_ajax_nopriv_get_time_slots', array($this, 'get_time_slots'));
        add_action('wp_ajax_get_booked_dates', array($this, 'get_booked_dates'));
        add_action('wp_ajax_nopriv_get_booked_dates', array($this, 'get_booked_dates'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_delete_appointment', array($this, 'delete_appointment'));
        add_action('wp_ajax_add_to_google_calendar', array($this, 'generate_google_calendar_link'));
        add_action('wp_ajax_update_meet_link', array($this, 'update_meet_link'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('appointment_scheduler_send_reminders', array($this, 'send_appointment_reminders'));
        add_action('wp', array($this, 'schedule_reminder_cron'));
    }
    
    public function init() {
        // Register shortcode
        add_shortcode('appointment_scheduler', array($this, 'render_scheduler'));
    }
    
    public function enqueue_scripts() {
        wp_enqueue_style(
            'appointment-scheduler-style',
            APPOINTMENT_SCHEDULER_PLUGIN_URL . 'assets/css/style.css',
            array(),
            APPOINTMENT_SCHEDULER_VERSION
        );
        
        wp_enqueue_script(
            'appointment-scheduler-script',
            APPOINTMENT_SCHEDULER_PLUGIN_URL . 'assets/js/script.js',
            array('jquery'),
            APPOINTMENT_SCHEDULER_VERSION,
            true
        );
        
        wp_localize_script('appointment-scheduler-script', 'appointmentScheduler', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('appointment_scheduler_nonce'),
            'timezone' => $this->get_timezone_string()
        ));
    }
    
    public function get_timezone_string() {
        // Get timezone from plugin settings first
        $appointment_timezone = get_option('appointment_timezone', '');
        if (!empty($appointment_timezone)) {
            return $appointment_timezone;
        }
        
        // Fallback to WordPress timezone
        $timezone = get_option('timezone_string');
        if (empty($timezone)) {
            $offset = get_option('gmt_offset');
            $timezone = 'UTC' . ($offset >= 0 ? '+' : '') . $offset;
        }
        return $timezone;
    }
    
    public function render_scheduler($atts) {
        $atts = shortcode_atts(array(
            'email' => get_option('admin_email'),
        ), $atts);
        
        ob_start();
        include APPOINTMENT_SCHEDULER_PLUGIN_DIR . 'templates/scheduler.php';
        return ob_get_clean();
    }
    
    public function get_time_slots() {
        check_ajax_referer('appointment_scheduler_nonce', 'nonce');
        
        $date = isset($_POST['date']) ? sanitize_text_field($_POST['date']) : '';
        $selected_date = isset($_POST['selected_date']) ? sanitize_text_field($_POST['selected_date']) : '';
        
        if (empty($date)) {
            wp_send_json_error(array('message' => 'Date is required'));
        }
        
        $time_slots = $this->generate_time_slots($date);
        $is_date_booked = $this->is_date_booked($date);
        
        wp_send_json_success(array(
            'date' => $date,
            'time_slots' => $time_slots,
            'selected_date' => $selected_date,
            'is_date_booked' => $is_date_booked
        ));
    }
    
    private function generate_time_slots($date) {
        // Get working hours from settings
        $start_time = get_option('appointment_start_time', '10:00');
        $end_time = get_option('appointment_end_time', '17:30');
        $interval = get_option('appointment_interval', 30); // minutes
        
        $slots = array();
        $start = strtotime($date . ' ' . $start_time);
        $end = strtotime($date . ' ' . $end_time);
        
        $current = $start;
        while ($current <= $end) {
            $time_str = date('g:ia', $current);
            $time_value = date('H:i', $current);
            
            // Check if slot is available (you can add custom logic here)
            $is_available = $this->is_slot_available($date, $time_value);
            
            $slots[] = array(
                'time' => $time_str,
                'value' => $time_value,
                'available' => $is_available
            );
            
            $current = strtotime('+' . $interval . ' minutes', $current);
        }
        
        return $slots;
    }
    
    private function is_slot_available($date, $time) {
        global $wpdb;
        
        // Check if date/time is in the past
        if (strtotime($date . ' ' . $time) < current_time('timestamp')) {
            return false;
        }
        
        // Check if this slot is already booked in the database
        $table_name = $wpdb->prefix . 'appointment_bookings';
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE appointment_date = %s AND appointment_time = %s",
            $date,
            $time
        ));
        
        if ($existing > 0) {
            return false; // Slot is already booked
        }
        
        // Get blocked times from settings
        $blocked_times = get_option('appointment_blocked_times', array());
        $date_time = $date . ' ' . $time;
        
        foreach ($blocked_times as $blocked) {
            if ($blocked['date'] === $date && $blocked['time'] === $time) {
                return false;
            }
        }
        
        return true;
    }
    
    private function is_date_booked($date) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'appointment_bookings';
        
        // Check if this date has any appointments
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE appointment_date = %s",
            $date
        ));
        
        return $count > 0;
    }
    
    public function get_booked_dates() {
        check_ajax_referer('appointment_scheduler_nonce', 'nonce');
        
        $year = isset($_POST['year']) ? intval($_POST['year']) : date('Y');
        $month = isset($_POST['month']) ? intval($_POST['month']) : date('m');
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'appointment_bookings';
        
        // Get all booked dates for this month
        $start_date = sprintf('%04d-%02d-01', $year, $month);
        $end_date = date('Y-m-t', strtotime($start_date));
        
        $booked_dates = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT appointment_date FROM $table_name 
             WHERE appointment_date >= %s AND appointment_date <= %s",
            $start_date,
            $end_date
        ));
        
        wp_send_json_success(array(
            'booked_dates' => $booked_dates
        ));
    }
    
    public function handle_appointment_submission() {
        check_ajax_referer('appointment_scheduler_nonce', 'nonce');
        
        $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
        $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
        $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
        $date = isset($_POST['date']) ? sanitize_text_field($_POST['date']) : '';
        $time = isset($_POST['time']) ? sanitize_text_field($_POST['time']) : '';
        $message = isset($_POST['message']) ? sanitize_textarea_field($_POST['message']) : '';
        
        // Validation
        if (empty($name) || empty($email) || empty($date) || empty($time)) {
            wp_send_json_error(array('message' => 'Please fill in all required fields.'));
        }
        
        if (!is_email($email)) {
            wp_send_json_error(array('message' => 'Please enter a valid email address.'));
        }
        
        // Check if this slot is already booked
        if (!$this->is_slot_available($date, $time)) {
            wp_send_json_error(array('message' => 'This time slot is already booked. Please select another time.'));
        }
        
        // Get admin email from settings or use default
        $admin_email = get_option('appointment_admin_email', get_option('admin_email'));
        
        // Format date and time
        $date_formatted = date('F j, Y', strtotime($date));
        $time_formatted = date('g:i A', strtotime($time));
        
        // Send email to admin - meet link will be added after saving
        $admin_subject = sprintf('New Appointment Booking - %s', $date_formatted);
        $admin_email_body = "A new appointment has been booked:\n\n";
        $admin_email_body .= "Name: $name\n";
        $admin_email_body .= "Email: $email\n";
        $admin_email_body .= "Phone: " . ($phone ? $phone : 'Not provided') . "\n";
        $admin_email_body .= "Date: $date_formatted\n";
        $admin_email_body .= "Time: $time_formatted\n";
        if ($message) {
            $admin_email_body .= "Message: $message\n";
        }
        $admin_email_body .= "\nGoogle Meet Link: \n"; // Will be replaced with actual link after saving
        $admin_email_body .= "\n---\n";
        $admin_email_body .= "This email was sent from your Appointment Scheduler plugin.";
        
        // Send email to user (confirmation) - meet link will be added after saving
        $user_subject = sprintf('Appointment Confirmation - %s', $date_formatted);
        $user_email_body = "Dear $name,\n\n";
        $user_email_body .= "Thank you for booking an appointment with us!\n\n";
        $user_email_body .= "Your appointment details:\n";
        $user_email_body .= "Date: $date_formatted\n";
        $user_email_body .= "Time: $time_formatted\n";
        if ($phone) {
            $user_email_body .= "Phone: $phone\n";
        }
        if ($message) {
            $user_email_body .= "Your Message: $message\n";
        }
        $user_email_body .= "\n";
        $user_email_body .= "Google Meet Link: \n"; // Will be replaced with actual link after saving
        $user_email_body .= "We look forward to meeting with you!\n\n";
        $user_email_body .= "If you need to reschedule or cancel, please contact us.\n\n";
        $user_email_body .= "---\n";
        $user_email_body .= "This is an automated confirmation email from Appointment Scheduler.";
        
        // Get additional emails from settings (can be multiple emails separated by comma)
        $additional_emails = get_option('appointment_additional_email', '');
        
        // Save to database FIRST to get appointment ID
        $appointment_id = $this->save_appointment($name, $email, $phone, $date, $time, $message);
        
        if (!$appointment_id) {
            wp_send_json_error(array(
                'message' => 'There was an error saving your appointment. Please try again.'
            ));
        }
        
        // Get the saved appointment with correct meet link
        global $wpdb;
        $table_name = $wpdb->prefix . 'appointment_bookings';
        $saved_appointment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d",
            $appointment_id
        ));
        
        // Use the saved meet link for emails
        $meet_link = !empty($saved_appointment->meet_link) ? $saved_appointment->meet_link : '';
        
        // Update user email with correct meet link
        if ($meet_link) {
            $user_email_body = str_replace("Google Meet Link: \n", "Google Meet Link: $meet_link\n", $user_email_body);
        }
        
        // Update admin email with correct meet link
        if ($meet_link) {
            $admin_email_body = str_replace("Google Meet Link: \n", "Google Meet Link: $meet_link\n", $admin_email_body);
        }
        
        // Send emails
        $headers = array('Content-Type: text/plain; charset=UTF-8');
        $admin_sent = wp_mail($admin_email, $admin_subject, $admin_email_body, $headers);
        $user_sent = wp_mail($email, $user_subject, $user_email_body, $headers);
        
        // Send email to additional emails if provided
        $additional_sent = false;
        if (!empty($additional_emails)) {
            // Split by comma and send to each email
            $email_array = array_map('trim', explode(',', $additional_emails));
            foreach ($email_array as $additional_email) {
                if (is_email($additional_email)) {
                    wp_mail($additional_email, $admin_subject, $admin_email_body, $headers);
                    $additional_sent = true;
                }
            }
        }
        
        // Check if email is Google account for auto calendar add
        $is_google_account = $this->is_google_account($email);
        $calendar_link = '';
        if ($saved_appointment) {
            // For user, create calendar link with admin as attendee
            $calendar_link = $this->create_google_calendar_link($saved_appointment, false);
        }
        
        if ($admin_sent) {
            wp_send_json_success(array(
                'message' => 'Your appointment has been booked successfully! A confirmation email has been sent to your email address.',
                'meet_link' => $meet_link,
                'is_google_account' => $is_google_account,
                'calendar_link' => $calendar_link
            ));
        } else {
            wp_send_json_error(array(
                'message' => 'There was an error sending your appointment request. Please try again.'
            ));
        }
    }
    
    private function save_appointment($name, $email, $phone, $date, $time, $message) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'appointment_bookings';
        
        // First insert without meet link
        $insert_id = $wpdb->insert(
            $table_name,
            array(
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'appointment_date' => $date,
                'appointment_time' => $time,
                'message' => $message,
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
        
        // Generate meet link with actual ID for uniqueness
        if ($insert_id) {
            $appointment_id = $wpdb->insert_id;
            $appointment = (object) array(
                'id' => $appointment_id,
                'appointment_date' => $date,
                'appointment_time' => $time
            );
            $final_meet_link = $this->generate_meet_link($appointment);
            $wpdb->update(
                $table_name,
                array('meet_link' => $final_meet_link),
                array('id' => $appointment_id),
                array('%s'),
                array('%d')
            );
            return $appointment_id;
        }
        
        return false;
    }
    
    private function is_google_account($email) {
        // Check if email is a Google account (gmail.com, googlemail.com, or Google Workspace)
        $google_domains = array('gmail.com', 'googlemail.com');
        $email_domain = strtolower(substr(strrchr($email, "@"), 1));
        
        // Check for Gmail
        if (in_array($email_domain, $google_domains)) {
            return true;
        }
        
        // Check if it's a Google Workspace domain (ends with .gmail.com or has Google Workspace)
        // This is a basic check - for full detection, would need Google API
        return false;
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'Appointment Scheduler',
            'Appointments',
            'manage_options',
            'appointment-scheduler',
            array($this, 'render_admin_page'),
            'dashicons-calendar-alt',
            30
        );
        
        add_submenu_page(
            'appointment-scheduler',
            'Settings',
            'Settings',
            'manage_options',
            'appointment-scheduler-settings',
            array($this, 'render_settings_page')
        );
    }
    
    public function register_settings() {
        register_setting('appointment_scheduler_settings', 'appointment_start_time');
        register_setting('appointment_scheduler_settings', 'appointment_end_time');
        register_setting('appointment_scheduler_settings', 'appointment_interval');
        register_setting('appointment_scheduler_settings', 'appointment_admin_email');
        register_setting('appointment_scheduler_settings', 'appointment_additional_email');
        register_setting('appointment_scheduler_settings', 'appointment_timezone');
        register_setting('appointment_scheduler_settings', 'appointment_blocked_times');
        register_setting('appointment_scheduler_settings', 'appointment_reminder_enabled');
        register_setting('appointment_scheduler_settings', 'appointment_reminder_times');
    }
    
    public function schedule_reminder_cron() {
        if (!wp_next_scheduled('appointment_scheduler_send_reminders')) {
            wp_schedule_event(time(), 'hourly', 'appointment_scheduler_send_reminders');
        }
    }
    
    public function send_appointment_reminders() {
        $reminder_enabled = get_option('appointment_reminder_enabled', 'yes');
        if ($reminder_enabled !== 'yes') {
            return;
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'appointment_bookings';
        $current_time = current_time('mysql');
        
        // Get appointments in next 24 hours
        $upcoming_appointments = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name 
            WHERE CONCAT(appointment_date, ' ', appointment_time) >= %s 
            AND CONCAT(appointment_date, ' ', appointment_time) <= DATE_ADD(%s, INTERVAL 24 HOUR)
            ORDER BY appointment_date, appointment_time",
            $current_time,
            $current_time
        ));
        
        foreach ($upcoming_appointments as $appointment) {
            $appointment_datetime = strtotime($appointment->appointment_date . ' ' . $appointment->appointment_time);
            $current_timestamp = current_time('timestamp');
            $time_diff = $appointment_datetime - $current_timestamp;
            
            // Send reminder 15 minutes before
            if ($time_diff <= 900 && $time_diff > 0 && empty($appointment->reminder_sent_15min)) {
                $this->send_reminder_email($appointment, '15min');
                $wpdb->update(
                    $table_name,
                    array('reminder_sent_15min' => 1),
                    array('id' => $appointment->id),
                    array('%d'),
                    array('%d')
                );
            }
            
            // Send reminder 1 hour before
            if ($time_diff <= 3600 && $time_diff > 900 && empty($appointment->reminder_sent_1hr)) {
                $this->send_reminder_email($appointment, '1hr');
                $wpdb->update(
                    $table_name,
                    array('reminder_sent_1hr' => 1),
                    array('id' => $appointment->id),
                    array('%d'),
                    array('%d')
                );
            }
            
            // Send reminder 1 day before
            if ($time_diff <= 86400 && $time_diff > 3600 && empty($appointment->reminder_sent_1day)) {
                $this->send_reminder_email($appointment, '1day');
                $wpdb->update(
                    $table_name,
                    array('reminder_sent_1day' => 1),
                    array('id' => $appointment->id),
                    array('%d'),
                    array('%d')
                );
            }
        }
    }
    
    private function send_reminder_email($appointment, $reminder_type) {
        $reminder_times = get_option('appointment_reminder_times', array('15min', '1hr', '1day'));
        if (!in_array($reminder_type, $reminder_times)) {
            return;
        }
        
        $reminder_text = array(
            '15min' => '15 minutes',
            '1hr' => '1 hour',
            '1day' => '1 day'
        );
        
        $date_formatted = date('F j, Y', strtotime($appointment->appointment_date));
        $time_formatted = date('g:i A', strtotime($appointment->appointment_time));
        $meet_link = !empty($appointment->meet_link) ? $appointment->meet_link : $this->generate_meet_link($appointment);
        
        $subject = sprintf('Reminder: Your appointment is in %s - %s', $reminder_text[$reminder_type], $date_formatted);
        
        $email_body = "Dear {$appointment->name},\n\n";
        $email_body .= "This is a reminder that you have an appointment scheduled:\n\n";
        $email_body .= "Date: $date_formatted\n";
        $email_body .= "Time: $time_formatted\n";
        
        if ($meet_link) {
            $email_body .= "Google Meet Link: $meet_link\n\n";
        }
        
        $email_body .= "We look forward to meeting with you!\n\n";
        $email_body .= "---\n";
        $email_body .= "This is an automated reminder from Appointment Scheduler.";
        
        $headers = array('Content-Type: text/plain; charset=UTF-8');
        wp_mail($appointment->email, $subject, $email_body, $headers);
        
        // Also send to admin
        $admin_email = get_option('appointment_admin_email', get_option('admin_email'));
        wp_mail($admin_email, $subject, $email_body, $headers);
    }
    
    public function generate_google_calendar_link() {
        check_ajax_referer('appointment_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission.'));
        }
        
        $appointment_id = isset($_POST['appointment_id']) ? intval($_POST['appointment_id']) : 0;
        
        if (empty($appointment_id)) {
            wp_send_json_error(array('message' => 'Invalid appointment ID.'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'appointment_bookings';
        $appointment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d",
            $appointment_id
        ));
        
        if (!$appointment) {
            wp_send_json_error(array('message' => 'Appointment not found.'));
        }
        
        // Get admin email for display
        $admin_email = get_option('appointment_admin_email', get_option('admin_email'));
        
        // Create calendar link for admin (admin will be the organizer)
        $calendar_link = $this->create_google_calendar_link($appointment, true);
        
        wp_send_json_success(array(
            'calendar_link' => $calendar_link,
            'meet_link' => !empty($appointment->meet_link) ? $appointment->meet_link : $this->generate_meet_link($appointment),
            'admin_email' => $admin_email,
            'message' => 'Google Calendar will open. Please make sure you are logged in with your admin Google account. The event will be added to your calendar.'
        ));
    }
    
    public function update_meet_link() {
        check_ajax_referer('appointment_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to update meet links.'));
        }
        
        $appointment_id = isset($_POST['appointment_id']) ? intval($_POST['appointment_id']) : 0;
        $new_meet_link = isset($_POST['meet_link']) ? esc_url_raw($_POST['meet_link']) : '';
        
        if (empty($appointment_id)) {
            wp_send_json_error(array('message' => 'Invalid appointment ID.'));
        }
        
        if (empty($new_meet_link)) {
            wp_send_json_error(array('message' => 'Meet link cannot be empty.'));
        }
        
        // Validate it's a Google Meet link
        if (strpos($new_meet_link, 'meet.google.com') === false) {
            wp_send_json_error(array('message' => 'Please enter a valid Google Meet link.'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'appointment_bookings';
        
        // Get current appointment
        $appointment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d",
            $appointment_id
        ));
        
        if (!$appointment) {
            wp_send_json_error(array('message' => 'Appointment not found.'));
        }
        
        $old_meet_link = $appointment->meet_link;
        
        // Update meet link
        $updated = $wpdb->update(
            $table_name,
            array('meet_link' => $new_meet_link),
            array('id' => $appointment_id),
            array('%s'),
            array('%d')
        );
        
        if ($updated !== false) {
            // Send notification emails about link change
            $this->send_meet_link_change_notification($appointment, $old_meet_link, $new_meet_link);
            
            wp_send_json_success(array(
                'message' => 'Meet link updated successfully. Notification emails have been sent.',
                'new_link' => $new_meet_link
            ));
        } else {
            wp_send_json_error(array('message' => 'Failed to update meet link.'));
        }
    }
    
    private function send_meet_link_change_notification($appointment, $old_link, $new_link) {
        $date_formatted = date('F j, Y', strtotime($appointment->appointment_date));
        $time_formatted = date('g:i A', strtotime($appointment->appointment_time));
        
        $subject = sprintf('Google Meet Link Updated - Appointment on %s', $date_formatted);
        
        $email_body = "Dear {$appointment->name},\n\n";
        $email_body .= "The Google Meet link for your appointment has been updated.\n\n";
        $email_body .= "Appointment Details:\n";
        $email_body .= "Date: $date_formatted\n";
        $email_body .= "Time: $time_formatted\n\n";
        $email_body .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $email_body .= "NEW GOOGLE MEET LINK:\n";
        $email_body .= "$new_link\n";
        $email_body .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
        
        if ($old_link) {
            $email_body .= "Previous link: $old_link\n\n";
        }
        
        $email_body .= "Please use the new link above to join the meeting.\n\n";
        $email_body .= "If you have any questions, please contact us.\n\n";
        $email_body .= "---\n";
        $email_body .= "This is an automated notification from Appointment Scheduler.";
        
        $headers = array('Content-Type: text/plain; charset=UTF-8');
        
        // Send to user
        wp_mail($appointment->email, $subject, $email_body, $headers);
        
        // Send to admin
        $admin_email = get_option('appointment_admin_email', get_option('admin_email'));
        wp_mail($admin_email, $subject, $email_body, $headers);
        
        // Send to additional emails
        $additional_emails = get_option('appointment_additional_email', '');
        if (!empty($additional_emails)) {
            $email_array = array_map('trim', explode(',', $additional_emails));
            foreach ($email_array as $additional_email) {
                if (is_email($additional_email)) {
                    wp_mail($additional_email, $subject, $email_body, $headers);
                }
            }
        }
    }
    
    private function create_google_calendar_link($appointment, $for_admin = false) {
        $start_date = strtotime($appointment->appointment_date . ' ' . $appointment->appointment_time);
        $end_date = $start_date + 3600; // 1 hour duration
        
        $start_iso = date('Ymd\THis\Z', $start_date);
        $end_iso = date('Ymd\THis\Z', $end_date);
        
        $title = urlencode('Appointment with ' . $appointment->name);
        $meet_link = !empty($appointment->meet_link) ? $appointment->meet_link : $this->generate_meet_link($appointment);
        
        // Get admin email
        $admin_email = get_option('appointment_admin_email', get_option('admin_email'));
        
        // Create detailed description with Meet link prominently displayed
        $details = "Appointment Details:\n\n";
        $details .= "Name: {$appointment->name}\n";
        $details .= "Email: {$appointment->email}\n";
        $details .= "Phone: " . ($appointment->phone ? $appointment->phone : 'N/A') . "\n\n";
        $details .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
        $details .= "🔗 JOIN GOOGLE MEET:\n";
        $details .= "$meet_link\n";
        $details .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n";
        $details .= "Click the link above to join the meeting at the scheduled time.";
        
        $details_encoded = urlencode($details);
        $location = urlencode('Online Meeting - Google Meet');
        
        // Create Google Calendar URL
        $calendar_url = "https://calendar.google.com/calendar/render?action=TEMPLATE";
        $calendar_url .= "&text=$title";
        $calendar_url .= "&dates=$start_iso/$end_iso";
        $calendar_url .= "&details=$details_encoded";
        $calendar_url .= "&location=$location";
        
        // Add attendees - this ensures event appears in both calendars
        // When admin clicks, add customer as attendee (admin is organizer by default)
        // When customer clicks, add admin as attendee (customer is organizer)
        if ($for_admin) {
            // Admin is creating - add customer as attendee
            if (!empty($appointment->email)) {
                $calendar_url .= "&add=" . urlencode($appointment->email);
            }
        } else {
            // Customer is creating - add admin as attendee so admin gets notification
            if (!empty($admin_email)) {
                $calendar_url .= "&add=" . urlencode($admin_email);
            }
        }
        
        return $calendar_url;
    }
    
    private function generate_meet_link($appointment) {
        // Generate a unique meet link based on appointment
        $meet_id = 'appt-' . md5($appointment->id . $appointment->appointment_date . $appointment->appointment_time);
        $meet_id = substr($meet_id, 0, 12);
        
        // Format: https://meet.google.com/xxx-xxxx-xxx
        $formatted_id = substr($meet_id, 0, 3) . '-' . substr($meet_id, 3, 4) . '-' . substr($meet_id, 7, 3);
        
        return 'https://meet.google.com/' . $formatted_id;
    }
    
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'toplevel_page_appointment-scheduler') {
            return;
        }
        
        // Use file modification time for cache busting
        $admin_js_version = file_exists(APPOINTMENT_SCHEDULER_PLUGIN_DIR . 'assets/js/admin.js') 
            ? filemtime(APPOINTMENT_SCHEDULER_PLUGIN_DIR . 'assets/js/admin.js') 
            : APPOINTMENT_SCHEDULER_VERSION;
        
        wp_enqueue_script(
            'appointment-scheduler-admin',
            APPOINTMENT_SCHEDULER_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            $admin_js_version,
            true
        );
        
        wp_localize_script('appointment-scheduler-admin', 'appointmentAdmin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('appointment_admin_nonce'),
            'confirm_delete' => __('Are you sure you want to delete this appointment? This action cannot be undone.', 'appointment-scheduler')
        ));
    }
    
    public function delete_appointment() {
        check_ajax_referer('appointment_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to delete appointments.'));
        }
        
        $appointment_id = isset($_POST['appointment_id']) ? intval($_POST['appointment_id']) : 0;
        
        if (empty($appointment_id)) {
            wp_send_json_error(array('message' => 'Invalid appointment ID.'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'appointment_bookings';
        
        $deleted = $wpdb->delete(
            $table_name,
            array('id' => $appointment_id),
            array('%d')
        );
        
        if ($deleted) {
            wp_send_json_success(array('message' => 'Appointment deleted successfully.'));
        } else {
            wp_send_json_error(array('message' => 'Failed to delete appointment.'));
        }
    }
    
    public function render_admin_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'appointment_bookings';
        $bookings = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");
        
        include APPOINTMENT_SCHEDULER_PLUGIN_DIR . 'templates/admin-page.php';
    }
    
    public function render_settings_page() {
        include APPOINTMENT_SCHEDULER_PLUGIN_DIR . 'templates/settings-page.php';
    }
    
    public static function activate() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'appointment_bookings';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            email varchar(100) NOT NULL,
            phone varchar(20),
            appointment_date date NOT NULL,
            appointment_time time NOT NULL,
            message text,
            meet_link varchar(255),
            reminder_sent_15min tinyint(1) DEFAULT 0,
            reminder_sent_1hr tinyint(1) DEFAULT 0,
            reminder_sent_1day tinyint(1) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Add new columns if they don't exist (for existing installations)
        $columns = $wpdb->get_col("DESC $table_name");
        if (!in_array('meet_link', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN meet_link varchar(255) AFTER message");
        }
        if (!in_array('reminder_sent_15min', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN reminder_sent_15min tinyint(1) DEFAULT 0 AFTER meet_link");
        }
        if (!in_array('reminder_sent_1hr', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN reminder_sent_1hr tinyint(1) DEFAULT 0 AFTER reminder_sent_15min");
        }
        if (!in_array('reminder_sent_1day', $columns)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN reminder_sent_1day tinyint(1) DEFAULT 0 AFTER reminder_sent_1hr");
        }
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Set default options
        add_option('appointment_start_time', '10:00');
        add_option('appointment_end_time', '17:30');
        add_option('appointment_interval', '30');
        add_option('appointment_admin_email', get_option('admin_email'));
    }
}

// Initialize plugin
Appointment_Scheduler::get_instance();

// Activation hook
register_activation_hook(__FILE__, array('Appointment_Scheduler', 'activate'));

